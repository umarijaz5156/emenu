<?php

return [

    'name'              => 'Iyzico',
    'description'       => 'This is my awesome module',

];