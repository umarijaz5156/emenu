<?php

return [

    'name'              => 'Webhooks',
    'description'       => 'This is my awesome module',

];