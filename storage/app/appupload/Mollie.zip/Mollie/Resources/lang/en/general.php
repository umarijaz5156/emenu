<?php

return [

    'name'              => 'Mollie',
    'description'       => 'This is my awesome module',

];