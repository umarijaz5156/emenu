<?php

return [

    'name'              => 'Glow',
    'description'       => 'This is my awesome module',

];