<?php

return [

    'name'              => 'Googletranslate',
    'description'       => 'This is my awesome module',

];