<?php

return [

    'name'              => 'PaypalSubscribe',
    'description'       => 'This is my awesome module',

];