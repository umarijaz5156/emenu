<?php

return [
    'name' => 'Themeswitcher'
];
