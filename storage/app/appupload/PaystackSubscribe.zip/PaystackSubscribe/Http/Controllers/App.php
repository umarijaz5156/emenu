<?php


namespace Modules\PaystackSubscribe\Http\Controllers;


class App
{
    public function validate($user)
    {
    }
}