<?php

return [

    'name'              => 'Mailchimp',
    'description'       => 'This is my awesome module',

];