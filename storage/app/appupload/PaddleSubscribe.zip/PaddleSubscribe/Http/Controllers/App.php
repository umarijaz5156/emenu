<?php


namespace Modules\PaddleSubscribe\Http\Controllers;


class App
{
    public function validate($user)
    {
    }
}