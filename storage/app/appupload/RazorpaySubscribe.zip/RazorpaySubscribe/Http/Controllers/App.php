<?php

namespace Modules\RazorpaySubscribe\Http\Controllers;

use Illuminate\Routing\Controller;

class App extends Controller
{
    public function validate($user)
    {
    }
}