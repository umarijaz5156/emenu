<?php

return [

    'name'              => 'Detrack',
    'description'       => 'This is my awesome module',

];