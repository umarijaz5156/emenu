<?php

return [
    'name' => 'PrintNode',
    'convert_api_secret' => env('CONVERT_API_SECRET','')
];
