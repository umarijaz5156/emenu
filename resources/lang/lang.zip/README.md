# Projects Translations files
Translation managment for CodeCanyon projects - FoodTiger, QRMenuMaker, Whatsapp food, etc...

# How to use
Download or clone this repository
Copy your desired language folder ex "it" and paste it in resources/lang folder (If exists)
Copy your desired language file ex "it.json" and paste it in resources/lang folder

# How to contribute
Clone this repository
Modify the files you found incorrect
Or add the language folder ex "it" and the language file ex "it.json"
And commit and submit the change. 
A pull request will be created that we will accept

Or directly in Github, modify the files that you find incorrect translation.
A pull request will be created that we will accept
