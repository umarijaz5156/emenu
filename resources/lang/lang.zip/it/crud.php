<?php

return array (
  'actions' => 'Azioni',
  'add_new_item' => 'Aggiungi nuovo :item',
  'back' => 'Indietro',
  'clear_filters' => 'Pulisci filtri',
  'delete' => 'Cancella',
  'download_report' => 'Download report',
  'edit' => 'Modifica',
  'edit_item_name' => 'Modifica :item :name',
  'enter_item_name' => 'Inserisci :item name',
  'filter' => 'Filtra',
  'item_has_been_added' => ':Item è stato aggiunto',
  'item_has_been_removed' => ':Item è stato cancellato',
  'item_has_been_updated' => ':Item è stato aggiornato',
  'item_has_items_associated' => ':Item è stato associato. Rimuovere gli articoli associati prima di eliminare questo :item.',
  'item_managment' => ':Item gestione',
  'new_item' => 'Nuovo :item',
  'no_items' => 'Non ci sono :items...',
);
