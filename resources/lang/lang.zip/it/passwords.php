<?php

return array (
  'reset' => 'La password è stata resettata!',
  'sent' => 'Abbiamo inviato via e-mail il collegamento per reimpostare la password!',
  'throttled' => 'Si prega di attendere prima di riprovare.',
  'token' => 'Il token di reimpostazione password non è valido.',
  'user' => 'Non riusciamo a trovare un utente con questa e-mail.',
);
