<?php

return array (
  'client_name' => 'Nome cliente',
  'client_phone' => 'Telefono cliente',
  'customer_phone_number' => 'Telefono cliente',
  'delivery_area_name' => 'Nome area di consegna',
);
