<?php

return array (
  'failed' => 'Queste credenziali non sono corrette.',
  'throttle' => 'Troppi tentativi di accesso. Prova di nuovo fra :seconds secondi.',
);
